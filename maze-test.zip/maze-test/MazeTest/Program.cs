using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace mazetest
{
    class Program
    {
		// Class that stores information for a point		
        public class Point
        {
            int x;
            int y;
            Point parent;

            public Point(int X, int Y)
            {
                 x = X;
                 y = Y;
                 parent = null;
            }

            public Point(int X, int Y, Point Parent)
            {
                x = X;
                y = Y;
                if (Parent != null)
                {
                    parent = (Point)Parent;
                }
                else parent = new Point(-1, -1);
            }

            public override string ToString()
            {
                return String.Format("({0}, {1})", x, y);
            }

            public List<Point> TracePath()
            {
                List<Point> path = new List<Point>();

                Point curPoint = this;

                path.Add(curPoint);

                while (curPoint.Parent != null && curPoint.Parent.X != -1)
                {
                    path.Add(curPoint.Parent);

                    
                    curPoint = curPoint.Parent;

                }

                path.Reverse();

                return path;
            }

            public Point Parent{
                get { return parent; }
            }

            public int X
            {
                get { return x; }
                set { value = x; }
            }
            public int Y
            {
                get { return y; }
                set { value = y; }
            }
        }
		
		// method to find the mazepath
        static List<Point> MazePathFinder(int X, int Y, bool[,] array, char[,] given)
        {
            Queue<Point> queue = new Queue<Point>();

            queue.Enqueue(new Point(X, Y, null));
            int startCol = Y;
            int StartRow = X;

            array[X, Y] = true; // mark current position as true, to show finder already been here
			// array is same size as maze grid
			// and is true where there is wall
			// or where the finder has already been

            while (queue.Count > 0)
            {
                Point current = queue.Dequeue();
				
				// Check if at end
                if (given[current.X, current.Y] == 'F' && current.X>= StartRow)
                {
                    List<Point> path = current.TracePath();
                    return path;
                }
				
				// Check Left
                if (!array[current.X - 1, current.Y])
                {
                    queue.Enqueue(new Point ( current.X - 1, current.Y, current ));
                    array[current.X - 1, current.Y] = true;
                }
				// Check Right
                if (!array[current.X + 1, current.Y])
                {
                    queue.Enqueue(new Point ( current.X + 1, current.Y , current));
                    array[current.X + 1, current.Y] = true;
                }
				// Check Below
                if (!array[current.X, current.Y - 1])
                {
                    queue.Enqueue(new Point ( current.X, current.Y - 1 , current));
                    array[current.X, current.Y - 1] = true;
                }
                // Check Above
                if (!array[current.X, current.Y + 1])
                {
                    queue.Enqueue(new Point(current.X, current.Y + 1, current));
                    array[current.X, current.Y + 1] = true;
                }


            }

            return null;
        }


        static void Main(string[] args)
        {
            StreamReader Input = new StreamReader("MAZE.txt");
           
            while (true)
            {
                int walls = 0;
                int spaces = 0;

                int length = int.Parse(Input.ReadLine());
                int width = int.Parse(Input.ReadLine());

                char[,] given = new char[width, length];
                bool[,] array = new bool[width, length];

                int[] start = new int[2];

                for (int row = 0; row < length; row++)
                {
                    string curLine = Input.ReadLine();
                    for (int column = 0; column < width; column++)
                    {
                        if (curLine[column] == 'X')
                        {
                            array[column, row] = true;
                            walls++;
                        }
                        else
                        {
                            array[column, row] = false;
                            spaces++;
                        }

                        given[column, row] = curLine[column];

                        if (curLine[column] == 'S') start = new int[] { column, row };
                    }
                }
                Console.WriteLine("No of Walls:" + walls + " and spaces:" + spaces + " including considering start and end point as space");
                List<Point> path = new List<Point>();
                PrintPath(path, given);
                //List<Point> 
                    path = MazePathFinder(start[0], start[1], array, given);
                
                Console.WriteLine("please enter coordinates you wated to know the value as Rows,Columns");
                string str=Console.ReadLine();
                string [] strSplit = str.Split(',');
                if (Convert.ToInt32(strSplit[0]) < length && Convert.ToInt32(strSplit[1]) < width)
                {
                    if (given[Convert.ToInt32(strSplit[1]), Convert.ToInt32(strSplit[0])] == 'X')
                    {
                        Console.WriteLine("coordinate Value: Wall");
                    }
                    else
                        Console.WriteLine("coordinate Value: Space");
                }
                else {
                    Console.WriteLine("Invalid coordinates");
                }
                PrintPath(path, given);

                Console.WriteLine();

                if (Input.EndOfStream) break;
            }

            Console.WriteLine("\nNOTE: \n'S', 'F', and 'X' are reserved for Start, End, and Walls\nand are not used for in-between steps");
            Console.ReadKey(true);
        }

        static void PrintPath(List<Point> path, char[,] given)
        {
            //If a path is possible, add it to given
            //If there is no path, skip this step
            if (path != null)
            {
               

                for (int step = 0; step < path.Count; step++)
                {
                    int x = path[step].X;
                    int y = path[step].Y;
                    if (step == 0) given[x, y] = 'S';
                    else if (step == path.Count - 1) given[x, y] = 'F';
                    else
                    {                        
                        //For # Steps                        
                        given[x, y] = '#';
                    }
                }
            }

                for (int row = 0; row < given.GetLength(1); row++)
                {
                    for (int column = 0; column < given.GetLength(0); column++)
                    {
                        char curChar = given[column, row];

                        if (curChar == 'S') Console.ForegroundColor = ConsoleColor.Green;
                        else if (curChar == 'F') Console.ForegroundColor = ConsoleColor.Red;
                        else if (curChar == 'X') Console.ForegroundColor = ConsoleColor.DarkGray;
                        else Console.ForegroundColor = ConsoleColor.Cyan;

                        Console.Write(curChar);
                    }

                    Console.WriteLine();
                }

                Console.ForegroundColor = ConsoleColor.Gray;

            if (path == null) Console.WriteLine("NO PATH POSSIBLE");
            else
            {if(path.Count>0)
                Console.WriteLine("{0} STEPS", path.Count - 1);
            }

        }
    }
}
